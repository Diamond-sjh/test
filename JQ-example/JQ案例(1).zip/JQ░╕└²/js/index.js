$(function () {
    // 初始化数据
    var datas = [
            {id:1,companyName:'北京市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            },
            {id:2,companyName:'南京市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            },
            {id:3,companyName:'上海市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            },
            {id:4,companyName:'深圳市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            },
            {id:5,companyName:'广州市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            },
            {id:6,companyName:'杭州市*****有限公司',
            compositeIndex:37.88,innovationIndex:16.36,
            OperatingIncome:8090.8,tax:238.32,
            SolidInvestment:0.00
            }
        ]
    // 将数据添加到页面方法
    function init(){
        datas.forEach(function(value,index){
            var tr = `
            <tr data-id="${value.id}">
                <td><input type="checkbox" style="width: 20px;height: 20px;"></td>
                <td>${value.companyName}</td>
                <td>${value.compositeIndex}</td>
                <td>${value.innovationIndex}</td>
                <td>${value.OperatingIncome}</td>
                <td>${value.tax}</td>
                <td>${value.SolidInvestment}</td>
                <td><a href="javascript:;">添加</a></td>
            </tr>
            `
            $('.tbOne').append(tr)
        })
    }
    init()
 
    // 初始化添加方法
    function add(obj) {
        var info = $(obj).parents('tr').children('td').eq(1).html()
        var dataId = $(obj).parents('tr').attr('data-id')
        //初始化模板
        var str = `<tr data-id="${dataId}">
            <td><input type="checkbox"></td>
            <td>${info}</td>
            <td><a href="javascript:;" class="del">×</a></td>
        </tr>`
        var tr = $(str)
        $('.tbTwo').append(tr)
        $(obj).parents('tr').children('td').last().children('a').text('已添加').css('color', '#ccc')
    }

    //初始化删除方法
    function del(e) {
        var delId = $(e).parents('tr').attr('data-id')
        $('.tbOne tr').each((i, ele) => {
            if (delId === $(ele).attr('data-id')) {
                $(ele).find('a').text('添加').removeAttr('style')
            }
        })
        $(e).parents('tr').remove()
        pendSubmit()
    }

    // 初始化待提交列表方法
    function pendSubmit() {
        var allDelTrs = $('.tbTwo').children('tr')
        $('.pend-sub-num').text('(' + allDelTrs.length + ')')
    }

    // 初始化提示信息方法
    function alertInfo(ele) {
        if (ele.length <= 0) {
            alert('请先选中要操作的条目!')
            return
        }
    }

    //初始化检测是否添加方法
    var status = true   //定义初始值  用来控制右侧是否有已添加的条目
    function checkAdd(element) {
        var res
        if ($('.tbTwo tr').length > 0) {
            // 这里不能使用each(),原因：each中使用break/continue和return不起作用
            for (var i = 0; i < $('.tbTwo tr').length; i++) {
                if (element.attr('data-id') == $('.tbTwo tr').eq(i).attr('data-id')) {
                    status = false
                    break
                } else {
                    status = true
                }
            }
            return status

        } else {
            return true
        }
    }

    // 单个添加
    $('.tbOne tr a').on('click', function () {
        // console.log(checkAdd($(this).parents('tr')))
        if (checkAdd($(this).parents('tr'))) {
            if (status) {
                add($(this))
                pendSubmit()
            } else {
                alert('所选条目中包含已添加的条目!')
            }
        } else {
            alert('所选条目中包含已添加的条目!')
        }
    })

    // 批量添加
    $('.allBtn').on('click', function () {
        alertInfo($('.tbOne tr input:checked'))
        // JQ中的.each()方法，用来遍历么，参数是一个回调函数，
        //       回调函数中可以传入两个参数，第一个是下标，第二个是被循环的每一个元素
        var inputs = $('.tbOne tr input:checked')
        for(var j = 0; j < inputs.length; j++){
            if (checkAdd(inputs.eq(j).parents('tr'))) {
                if (status) {
                    add(inputs.eq(j))
                    pendSubmit()
                    inputs.eq(j).prop('checked', false)
                } else {
                    alert('所选条目中包含已添加的条目!')
                    break
                }
            } else {
                alert('所选条目中包含已添加的条目!')
                break
            }
        }
    })

    // 单个删除
    $(document).on('click', '.del', function () {
        del(this)
    })

    // 批量删除
    $('.alldel').on('click', function () {
        alertInfo($('.tbTwo tr input:checked'))
        $('.tbTwo tr input:checked').each((index, ele) => {
            del(ele)
        })
    })

    //清空
    $('.clear').on('click', function () {
        if ($('.tbTwo').find('tr').length > 0) {
            if (confirm('确定要清空吗?')) {
                $('.tbTwo').find('tr').remove()
                $('.tbOne').find('a').text('添加').removeAttr('style')
                pendSubmit()
            }
        } else {
            alert('没有条目可清空!')
        }
    })
})